Photo Gallery Module
=================

Author
-----------------
Computer Know How, LLC/Seth Engen

Summary
-----------------
This module will generate photo galleries for your ContentBox websites.

Install Instructions
-----------------
Download code and extract it to your ContentBox modules folder in the ContentBox module or install from the download manager.

Change Log
-----------------
* Version 1.1 - Updated for ContentBox 3
* Version 1.0 - Initial Release